const { expect } = require('@wdio/globals');
const HomePage = require('../pageobjects/HomePage');
const commonMethods = require('../../utils/commonMethods');
const FindCruisePage = require('../pageobjects/FindCruisePage');
const GlobalSearch = require('../pageobjects/GlobalSearchPage');
const GlobalSearchPage = require('../pageobjects/GlobalSearchPage');
//const LoginPage = require('../pageobjects/login.page')
//const SecurePage = require('../pageobjects/secure.page')

describe('My Login application', () => {
    it('User logs in with incorrect credentials', async() => {
        await browser.url('http://www.hollandamerica.com/');
        await HomePage.cookiePopupClick();
        await commonMethods.verifyTitleOfThePage("Find Cruise Packages for Holland America's Award-Winning Cruises");
        await HomePage.loginMethod('abc@gmail.com', '1223234');
        await HomePage.verifyLoginErrorMessage("Invalid username, mariner id or password given.");
    })

    it('User Navigates to Find Cruise Page', async() => {
        await HomePage.navigationToFindCruisePage();
        await commonMethods.verifyTitleOfThePage("Find Cruises - Search Cruise Itineraries 2024, 2025, & 2026");
        await FindCruisePage.selectViewResultsFor("HAVE IT ALL");
    });

    it('User verifies global search functionality', async() => {
        FindCruisePage.globalSearchButtonClick();
        GlobalSearchPage.globalSearchFor('hilo hawaii us');
        GlobalSearchPage.searchValidationResults('Cruises Destinations - Search 2024 & 2025 Cruise Itineraries');
        await $('//button[@data-automation-id="global-search-search"]').click();
        expect(await $('//a[@data-automation-id="global-search"]').getText()).toEqual('Cruises Destinations - Search 2024 & 2025 Cruise Itineraries');

    });
})