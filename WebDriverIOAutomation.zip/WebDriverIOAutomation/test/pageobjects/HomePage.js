class HomePage {

    get cookiePopup() {
        return $('#onetrust-accept-btn-handler');
    }

    get loginButton() {
        return $('#loginModalComponentButton');
    }

    get userNameTextBox() {
        return $('#emailInput');
    }

    get passwordTextBox() {
        return $('//input[@type="password"]');
    }

    get submitButton() {
        return $('//button[@type="submit"]');
    }

    get loginErrorMessage() {
        return $('//div/span[@id="loginModalApiError"]');
    }
    get loginBlockCloseButton() {
        return $('//div[@aria-label="Close"]');
    }

    get bookACruiseButton() {
        return $('//a[@data-id="Bookacruise"]');
    }

    get findACruiseButton() {
        return $('//a[text()="Find Cruises"]');
    }


    //method to accept cookie popup
    async cookiePopupClick() {
        await this.cookiePopup.click();
    }

    //method for login
    async loginMethod(userName, password) {
        await this.loginButton.click();
        await this.userNameTextBox.setValue(userName);
        await this.passwordTextBox.setValue(password);
        await this.submitButton.click();
    }

    //method to validate error message
    async verifyLoginErrorMessage(expectedErrorMessage) {
        await this.loginErrorMessage.waitForDisplayed(8000);
        let errorMessage = await this.loginErrorMessage.getText();
        await expect(errorMessage).toEqual(expectedErrorMessage);
        await this.loginBlockCloseButton.click();
    }

    async navigationToFindCruisePage() {
        await this.bookACruiseButton.click();
        await this.findACruiseButton.click();
    }
}
module.exports = new HomePage;