const commonMethods = require("../../utils/commonMethods");

class GlobalSearchPage {

    get searchBox() {
        return $('//input[@data-automation-id="global-search-input"]');
    }
    get searchList() {
        return $$('//ul[@class="input-suggestion-wrap__suggestions__list"]/li/a');
    }

    get searchButton() {
        return $('//button[@data-automation-id="global-search-search"]');
    }

    get searchResults() {
        return $('//a[@data-automation-id="global-search"]');
    }


    async globalSearchFor(locationName) {
        await this.searchBox.setValue(locationName);
        await commonMethods.selectFromStaticDropdownWithoutSelectTag(await this.searchList, locationName);
        await this.searchButton.click();
    }
    async searchValidationResults(searchResults) {
        expect(await this.searchResults.getText()).toEqual(searchResults);
    }
}
module.exports = new GlobalSearchPage;