const commonMethods = require("../../utils/commonMethods");

class FindCruisePage {

    get viewResultsFor() {
        return $('//div[@data-automation-id="View-Result-filter-button"]/span');
    }

    get viewResultsForElementsList() {
        return $$('//div[@id="view-result-dropdown"]/a/span');
    }

    get globalSearchButton() {
        return $('//a[@data-automation-id="find-a-cruise-Search"]');
    }

    async selectViewResultsFor(dropDownText) {
        await this.viewResultsFor.click();
        await browser.pause(3000);
        await commonMethods.selectFromStaticDropdownWithoutSelectTag(await this.viewResultsForElementsList, dropDownText);
    }

    async globalSearchButtonClick() {
        await this.globalSearchButton.click();
    }
}
module.exports = new FindCruisePage;