class commonMethods {

    async verifyTitleOfThePage(expectedTitle) {
        browser.waitUntil(() => {
            return browser.getTitle();
        })
        let pageTitle = await browser.getTitle();
        await expect(pageTitle).toEqual(expectedTitle);
    }

    async selectFromStaticDropdownWithoutSelectTag(listOfElements, dropDownToBeSelected) {
        let elementList = await listOfElements;
        for (let i = 0; i < elementList.length; i++) {
            let searchText = await elementList[i].getText();
            if (searchText.includes(dropDownToBeSelected)) {
                await elementList[i].click();
                break;
            }
        }
    }
}
module.exports = new commonMethods();